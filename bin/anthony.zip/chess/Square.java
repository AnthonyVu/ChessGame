package chess;

import java.awt.Color;
import java.io.Serializable;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Square implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private JButton button;
    private Color color;
    private ImageIcon img;
    Piece piece;

    public Square(Color color) {
        button = new JButton();
        this.color = color;
        button.setBackground(color);
        img = null;
    }

    public boolean holdingPiece() {
        if (img != null) {
            return true;
        }
        return false;
    }

    public Color getColor() {
        return color;
    }

    public JButton getButton() {
        return button;
    }

    public ImageIcon getImage() {
        return this.img;
    }

    public void setPiece(Piece piece) {
        this.piece = piece;
        this.img = piece.getImage();
        button.setIcon(img);
    }

    public Piece getPiece() {
        return this.piece;
    }

    public String getPieceColor() {
        if (holdingPiece() == true) {
            return this.piece.getColor();
        }
        return null;
    }

    public void setImage(ImageIcon img) {
        this.img = img;
        button.setIcon(this.img);
    }
}
