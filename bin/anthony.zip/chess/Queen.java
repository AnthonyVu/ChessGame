package chess;

import java.io.Serializable;

import javax.swing.ImageIcon;

public class Queen extends Piece implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private ImageIcon icon;
    private String color;
    private String type;

    public Queen(String color) {
        if(color.equals("black")) {
            icon = new ImageIcon("Queen.png");
        }else {
            icon = new ImageIcon("grayQueen.png");
        }
        this.color = color;
        type = "Queen";
    }

    public ImageIcon getImage() {
        return icon;
    }

    public String getColor() {
        return color;
    }

    public String pieceType() {
        return type;
    }
}
