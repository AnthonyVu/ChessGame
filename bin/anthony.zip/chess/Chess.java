package chess;

public class Chess{

    public static void main(String[] args) {
        Board b = new Board();
    }
}

