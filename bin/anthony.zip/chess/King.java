package chess;

import java.io.Serializable;

import javax.swing.ImageIcon;

public class King extends Piece implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private ImageIcon icon;
    private String color;
    private String type;

    public King(String color) {
        if(color.equals("black")) {
            icon = new ImageIcon("King.png");
        } else {
            icon = new ImageIcon("grayKing.png");
        }
        this.color = color;
        type = "King";
    }

    public ImageIcon getImage() {
        return icon;
    }
    
    public String getColor() {
        return color;
    }
    
    public String pieceType() {
        return type;
    }
}
