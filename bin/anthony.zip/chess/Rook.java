package chess;

import java.io.Serializable;

import javax.swing.ImageIcon;

public class Rook extends Piece implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private ImageIcon icon;
    private String color;
    private String type;

    public Rook(String color) {
        if(color.equals("black")) {
            icon = new ImageIcon("Rook.png");
        } else {
            icon = new ImageIcon("grayRook.png");
        }
        this.color = color;
        type = "Rook";
    }

    public ImageIcon getImage() {
        return icon;
    }

    public String getColor() {
        return color;
    }

    public String pieceType() {
        return type;
    }
}
