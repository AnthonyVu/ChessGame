package chess;

import java.io.Serializable;

public class Player implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String color;

    public Player(String color) {
        this.color = color;
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
