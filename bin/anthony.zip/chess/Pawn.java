package chess;

import java.io.Serializable;

import javax.swing.ImageIcon;

public class Pawn extends Piece implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private ImageIcon icon;
    private String color;
    private String type;

    public Pawn(String color) {
        if (color.equals("black")) {
            icon = new ImageIcon("Pawn.png");
        } else {
            icon = new ImageIcon("grayPawn.png");
        }
        this.color = color;
        type = "Pawn";
    }

    public ImageIcon getImage() {
        return icon;
    }

    public String getColor() {
        return color;
    }

    public String pieceType() {
        return type;
    }
}
