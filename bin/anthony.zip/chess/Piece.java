package chess;

import javax.swing.ImageIcon;

abstract class Piece {
    private ImageIcon icon;
    private String color;
    private String type;
    private boolean doneFirstMove = false;
    
    public ImageIcon getImage() {
        return icon;
    }

    public String getColor() {
        return color;
    }

    public String pieceType() {
        return type;
    }
    
    public void firstMoveComplete() {
        doneFirstMove = true;
    }
    
    public boolean isFirstMoveCompleted() {
        return doneFirstMove;
    }
}
